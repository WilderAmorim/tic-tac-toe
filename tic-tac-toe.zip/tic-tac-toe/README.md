lang="en"
Tic Tac Toe.
Made by: Rayllander Sotero (@rayllandersotero);
Year: 2019;
Liabilities: HTML, Javascript and CSS;
Linking: Bootstrap v4.3.1 and Fontawesome v5.6.3;
Objective: Purpose of learning and fun, open to third-party opinions and improvements.

/-----/-----/

lang="pt-br"
Jogo da velha.
Feito por: Rayllander Sotero (@rayllandersotero);
Ano: 2019;
Linguagens: HTML, Javascript and CSS;
Vinculação: Bootstrap v4.3.1 e Fontawesome v5.6.3;
Objetivos: Fins de aprendizado e divertimento, aberto para opniões e melhorias de terceiros.